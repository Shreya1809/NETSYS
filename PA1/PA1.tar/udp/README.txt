PA1 - 09/23/18 - Shreya Chakraborty
Aim of this submission : Reliable transfer of files over socket using UDP
The submission folder udp  contains two 2 sub folders client folder and server folder. The contents of each of them is described as below:
Client folder(client_folder) 
1. udp_client.c : The framework provided in the example code. This file contains the main function which accesses the functions given in the other files
2. commands.c/.h: This file contains all the command handler functions for various commands like get,put,ls,delete exit etc. The user input is valiadated and then the control is sent to the respective commands
3. reliability_client.c/.h : This is the main file used for reliability for UDP. It contains two functions one for receiving the file and other for sending the file
4. Makefile 
Server folder(server_folder)
1. udp_server.c: The same framework for server as provided in the example code
2. server_handler.c/.h
3. reliability_server.c/.h
4. Makefile
        
The structure of the code is simple. The user inputs the option it wants to execute in the client. The client then matches the entered option to the command index for the particular command. The command index and the filename (for get , put , delete) are then sent over to the server. The command index is then matched to the corresponding command handler in the server and the operation is executed with the received filename. 
The commands are handled in the client section in the file commands.c. 
The general flow of the operation is given as below:
1. The user enters the input which is matched to a particular option.

For eg "get foo1" matches to option 0 
2. This option is given as a parameter to the function commandhandler(available in commands.c) which has a switch case.
3. The command handler then send control over to the corresponding operation. The functions to handle the commands are:
a. void getfile(int sockfd,char *filename,struct sockaddr_in server_addr);
b. void putfile(int sockfd,char *filename,struct sockaddr_in server_addr);
c. void deletefile(int sockfd,char *filename,struct sockaddr_in server_addr);
d. void listfiles(int sockfd,struct sockaddr_in server_addr);
e. void serverexit(int sockfd, struct sockaddr_in server_addr);
4. The filename received in the following functions are checked if they exist or not is they do then a File exist message is sent to the server/client if they don't a file not exit message is sent.
5.  If the file exits the size of the file is calculated and send over to the client/server and then then actual transfer of data begins.
6. The data is encapsulated inside a structure  containing data, sequence number and code. The data is the actual data to be sent and I am sending 1kb data at a time, the sequence number keeps count of the number of data packets send and received, the code is a enum which gives information about data and ack. The two codes used normally are UDP_SEND and UDP_ACK.
7. The reliability scheme that has been used to make UDP transfer reliable is the stop and wait protocol. There are 3 scenarios in this case:
a. The server and the client work normally without any packet loss or ack loss(happy case):The server/client sends data to the client/server with code UDP_SEND and then immediately starts waiting for the ACK. The receiver receives the packet, checks if the received code is UDP_SEND, checks the sequence number, if the sequence number matches, it sends a packet with code UDP_ACK. Then the receiver writes the received data to the file created and increments the current sequence count. The sender then receives the ACK packet increments its own sequence number and then sends the next packet.
b. If packet loss occurs: If by some chance the internet is disconnected or there is a lot of traffic, the sending and receiving will be slower than usual. In this case I have given the recv_from function some buffer time ie timeout to keep on checking for the data. If timeout occurs (which is kept to 2 secs) the  control goes back to recv_from function and waits again. It keeps on doing this until it finally gets the data for the receiver side. And similarly for the sender side, if it does not receive an ACK it will keep on sending the earlier packet until it receives the ack. Neither sender nor receiver moves forward in this case.
c. If ACK loss occurs: In case the data from the sender has been received and the receiver sends an ACK back to the sender and it gets lost somehow, the receiver is currently waiting for the next data timeouts and realizes the ACK has been lost , the sender timeouts and realizes the ack has been lost simultaneously so it resends the old packet. The receiver checks the sequence number and realizes it received the old data which was resent, in this case it send the acknowledgment for the old data and does not increment the current sequence count. 
8. The reliability has been implemented for the file exchange alone ie the get file and put fiel. And in that too for sending and receiving the actual data of the file. In the end right after the file transfer I execute a system command md5sum for the given file name for both the server and client for get/put functions to check if the values are same or different.
9. For the commands other than get and put, the working and explanation is very simple.
a. For delete file command, after the option matching and going into the corresponding delete file function, the client sends the file name with the command index for the function to the server. The server receives the command index first and then goes to the corresponding server function handling delete file, then receives the filename to be deleted and simple removes it.
b. The list file command is similar but in this case only the command index is being sent. It makes a list of all the files names in the current directory using the built in functions like opendir, readdir from dirent.h and put the names into a buffer and send it over to the client.
c. The exit server command just sends the command index to the server which exits it gracefully.

The client and the server are continuously running in a loop. The server can remain on forever while the client is exited and entered with the server working in the same way. For compiling the files just type 'make' for the two folders separately. If in rare cases make fails, do 'make clean' and then 'make'.
The client has been executed by using the command --> ./client (ip address of server) (port)
The server has been executed using the command --> ./server (port)

References:
1. https://www.geeksforgeeks.org/c-program-list-files-sub-directories-directory/
2. Stackoverflow
3. Makefile taken from RTES summer course  by prof Sam Siewert.
4. The code framework given by Prof Sangtae Ha.

A better version of the readme with pictures has been included in the submission folder.




